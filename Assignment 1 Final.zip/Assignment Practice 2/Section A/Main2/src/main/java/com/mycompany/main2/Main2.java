/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main2;

/**
 *
 * @author JABULANI
 */
public class Main2 {

    public static void main(String[] args) {
        Series seriesApp = new Series();
        
        seriesApp.LaunchMenu();
    }
}
