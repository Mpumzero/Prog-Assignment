/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main2;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author JABULANI
 */





public class Series {
    
    
    public class SeriesModel {
    public String SeriesId;
    public String SeriesName;
    public String SeriesAge;
    public String SeriesNumberOfEpisodes;
    
    public SeriesModel(String seriesId, String seriesName, String seriesAge, String seriesNumberOfEpisodes) {
        this.SeriesId = seriesId;
        this.SeriesName = seriesName;
        this.SeriesAge = seriesAge;
        this.SeriesNumberOfEpisodes = seriesNumberOfEpisodes;
    }
    
}
    
    
    private ArrayList<SeriesModel> SeriesList;
    private Scanner scanner;
    
  public Series() {
        SeriesList = new ArrayList<>();
        scanner = new Scanner(System.in);
    }  
  
  public void LaunchMenu(){
      
      
      while(true){
          System.out.println("Welcome to the series streaming application");
        System.out.println("");
        System.out.println("LATEST SERIES - 2025");
        System.out.println("*********************************************************************");
        System.out.println("Enter (1) to launch menu or any other key to exit : ");
        String choice = scanner.nextLine();
        
        if (!choice.equals("1")) {
                ExitSeriesApplication();
                break;
            } else {
                boolean continueMenu = true;
        
                while (continueMenu) {
                    displayMenu();
       
                            String menuChoice = scanner.nextLine();
                    switch (menuChoice) {
                        case "1" -> CaptureSeries();
                        case "2" -> SearchSeries();
                        case "3" -> UpdateSeries();
                        case "4" -> DeleteSeries();
                        case "5" -> SeriesReport();
                        case "6" -> {
                            ExitSeriesApplication();
                            continueMenu = false;
                        }
                        default -> System.out.println("Invalid menu option. Please try again.");
                    }
                }
            }
        }
        scanner.close();
        
        }
        
        
       private void displayMenu() {
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new series.");
        System.out.println("(2) Search for a series.");
        System.out.println("(3) Update series age restriction");
        System.out.println("(4) Delete a series.");
        System.out.println("(5) Print series report - 2025");
        System.out.println("(6) Exit Application.");
        System.out.print("Your choice: ");
    }
       
       
       public void CaptureSeries() {
        System.out.println("\nCAPTURE A NEW SERIES");
        System.out.println("*************************");
        System.out.print("Enter the series id: ");
        String id = scanner.nextLine();
        System.out.print("Enter the series name: ");
        String name = scanner.nextLine();
        
        String age;
        while (true) {
            System.out.print("Enter the series age restriction: ");
            age = scanner.nextLine();
            if (isValidAge(age)) {
                break;
            } else {
                System.out.println("You have entered a incorrect series age!!!");
                System.out.println("Please re-enter the series age >>");
            }
        }
        
        
        System.out.print("Enter the number of episodes for " + name + ": ");
        String episodes = scanner.nextLine();
        SeriesModel newSeries = new SeriesModel(id, name, age, episodes);
        SeriesList.add(newSeries);
        System.out.println("Series processed successfully!!!");
        System.out.println("Enter (1) to launch menu or any other key to exit: ");
        String option = scanner.nextLine();
        if (!option.equals("1")) {
            ExitSeriesApplication();
            System.exit(0);
        }
    }
      
      
      // Validate age - must be an integer between 2 and 18 inclusive
    private boolean isValidAge(String input) {
        try {
            int age = Integer.parseInt(input);
            return (age >= 2 && age <= 18);
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    public void SearchSeries() {
        System.out.print("\nEnter the series id to search: ");
        String id = scanner.nextLine();
        System.out.println("----------------------------------------");
        SeriesModel found = findSeriesById(id);
        if (found != null) {
            displaySeriesDetails(found);
        } else {
            System.out.println("Series with Series Id: " + id + " was not found!");
        }
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String option = scanner.nextLine();
        if (!option.equals("1")) {
            ExitSeriesApplication();
            System.exit(0);
        }
    }
    
    // Find series by ID (helper)
    private SeriesModel findSeriesById(String id) {
        for (SeriesModel s : SeriesList) {
            if (s.SeriesId.equals(id)) {
                return s;
            }
        }
        return null;
    }
      
      
      private void displaySeriesDetails(SeriesModel series) {
        System.out.println("SERIES ID: " + series.SeriesId);
        System.out.println("SERIES NAME: " + series.SeriesName);
        System.out.println("SERIES AGE RESTRICTION: " + series.SeriesAge);
        System.out.println("SERIES NUMBER OF EPISODES: " + series.SeriesNumberOfEpisodes);
    }
      
     // 1.6 Update series
    public void UpdateSeries() {
        System.out.print("Enter the series id to update: ");
        String id = scanner.nextLine();
        SeriesModel toUpdate = findSeriesById(id);
        if (toUpdate == null) {
            System.out.println("Series with Series Id: " + id + " was not found!");
        } else {
            System.out.print("Enter the series name: ");
            toUpdate.SeriesName = scanner.nextLine();
      
      while (true) {
                System.out.print("Enter the age restriction: ");
                String age = scanner.nextLine();
                if (isValidAge(age)) {
                    toUpdate.SeriesAge = age;
                    break;
                } else {
                    System.out.println("You have entered a incorrect series age!!!");
                    System.out.println("Please re-enter the series age >>");
                }
            }
            System.out.print("Enter the number of episodes: ");
            toUpdate.SeriesNumberOfEpisodes = scanner.nextLine();
        }

        
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String option = scanner.nextLine();
        if (!option.equals("1")) {
            ExitSeriesApplication();
            System.exit(0);
        }
    }
    
    // 1.7 Delete series
    public void DeleteSeries() {
        System.out.print("Enter the series id to delete: ");
        String id = scanner.nextLine();
        
        SeriesModel toDelete = findSeriesById(id);
        if (toDelete == null) {
            System.out.println("Series with Series Id: " + id + " was not found!");
        } else {
            System.out.print("Are you sure you want to delete series " + id + " from the system? Yes (y) to delete: ");
            String confirm = scanner.nextLine();
            if (confirm.equalsIgnoreCase("y")) {
                SeriesList.remove(toDelete);
                System.out.println("--------------------------------");
                System.out.println("Series with Series Id: " + id + " WAS deleted!");
                System.out.println("--------------------------------");
            } else {
                System.out.println("Delete action cancelled.");
            }
        }
      
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String option = scanner.nextLine();
        if (!option.equals("1")) {
            ExitSeriesApplication();
            System.exit(0);
        }
    }
    
    // 1.8 Series Report
    public void SeriesReport() {
        System.out.println();
        int count = 1;
        for (SeriesModel s : SeriesList) {
            System.out.println("Series " + count++);
            System.out.println("----------------------------------------");
            displaySeriesDetails(s);
            System.out.println("----------------------------------------");
        }
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String option = scanner.nextLine();
        if (!option.equals("1")) {
            ExitSeriesApplication();
            System.exit(0);
        }
    }
    
    // 1.10 Exit Application
    public void ExitSeriesApplication() {
        System.out.println("Exiting the application. Goodbye!");
        System.exit(0);
    }
}
      
      
      
      
      
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

