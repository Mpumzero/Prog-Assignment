/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.main2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author JABULANI
 */
public class SeriesManagerTest {
    
   private SeriesManager seriesManager;
    @BeforeEach
    public void setup() {
        seriesManager = new SeriesManager();
        // You can initialize some test data here if needed
        seriesManager.addSeries(new Series(1, "Breaking Bad", 18));
        seriesManager.addSeries(new Series(2, "Friends", 13));
    }
    
    @Test
    public void TestSearchSeries() {
        Series series = seriesManager.searchSeries(1);
        assertNotNull(series, "Series should be returned for valid ID");
        assertEquals("Breaking Bad", series.getName(), "Series name should match");
    }
    @Test
    public void TestSearchSeries_SeriesNotFound() {
        Series series = seriesManager.searchSeries(999);
        assertNull(series, "No series should be found for incorrect ID");
    }
    
    @Test
    public void TestUpdateSeries() {
        Series updatedSeries = new Series(1, "Breaking Bad - Updated", 18);
        boolean result = seriesManager.updateSeries(updatedSeries);
        assertTrue(result, "Series should be successfully updated");
        Series series = seriesManager.searchSeries(1);
        assertEquals("Breaking Bad - Updated", series.getName(), "Updated name should be reflected");
    }
    @Test
    public void TestDeleteSeries() {
        boolean result = seriesManager.deleteSeries(2);
        assertTrue(result, "Series should be successfully deleted");
        Series series = seriesManager.searchSeries(2);
        assertNull(series, "Deleted series should not be found");
    }
    
    @Test
    public void TestDeleteSeries_SeriesNotFound() {
        boolean result = seriesManager.deleteSeries(999);
        assertFalse(result, "Deletion should fail for non-existing series");
    }
    @Test
    public void TestSeriesAgeRestriction_AgeValid() {
        boolean isValid = seriesManager.validateAgeRestriction(1, 18);
        assertTrue(isValid, "Age restriction should be valid for this series and age");
    }
    @Test
    public void TestSeriesAgeRestriction_SeriesAgeInValid() {
        boolean isValid = seriesManager.validateAgeRestriction(1, 15);
        assertFalse(isValid, "Age restriction should be invalid for below age limit");
    }
}
    

    /**
     * Test of main method, of class Main2.
     */
    @org.junit.jupiter.api.Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Main2.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
