/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author JABULANI
 */

    public class Calculations extends Operations {
    public double calculateSimpleInterest(double principal, double rate, double years) {
        return principal * (rate / 100) * years;
    }
    public double calculateCompoundInterest(double principal, double rate, double years) {
        return principal * (Math.pow(1 + rate/100, years) - 1);
    }
    public double calculateDepreciationStraightLine(double principal, double rate, double years) {
        return principal * (rate/100) * years;
    }
    public double calculateDepreciationReducingBalance(double principal, double rate, double years) {
        return principal - principal * Math.pow(1 - rate/100, years);
    }
}
    

