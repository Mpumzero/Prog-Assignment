/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

import java.util.Scanner;

/**
 *
 * @author JABULANI
 */
public class Operations {
    Scanner MM = new Scanner(System.in);
    Operations2 obj = new Operations2();
    
    
    public void SimpleInterest(){
        // A=P (1 + in)
        
        double[ ] PrincAmount = new double[ 1]; 
        double[ ] IntAmount = new double[ 1]; 
        double[ ] NumOfYears = new double[ 1]; 
        int count =1;
        
        
        
        System.out.println(" We will Calculate Simple Interest using the formula A=P (1 + in) ");
        System.out.println(" 1  is a contant so you will need to enter the other values to complete the formula and get your answer");
        
        for(int i = 0 ; i <count;   i++){
            System.out.println("(P) Enter the Principal Amount :  ");
            PrincAmount[i] = MM.nextDouble();
        }
        
         for(int i = 0 ; i <count;   i++){
            System.out.println("(i) Enter the Interest Amount  :  ");
            IntAmount[i] = MM.nextDouble();
        }
         
          for(int i = 0 ; i <count;   i++){
            System.out.println("(n) Enter the Number Of Years  :  ");
            NumOfYears[i] = MM.nextDouble();
        }
          
          for(int i = 0 ; i <count;   i++){
            double sum =PrincAmount[i] * (1 +  IntAmount[i]/100 * NumOfYears[i]);
              System.out.println("The complete formula is ");
              System.out.println("A = " + PrincAmount[i] + " (1 +" +IntAmount[i] +" * " +  NumOfYears[i]+")");
              System.out.println("");
              System.out.println("The Simple Interest is : " + sum);
        }
          
          
        
        System.out.println("");
    }
    
    public void CompundInterest(){
  // A = P (1 + n)*i
  
   double[ ] PrincAmount = new double[ 1]; 
        double[ ] IntAmount = new double[ 1]; 
        double[ ] NumOfYears = new double[ 1]; 
        int count =1;
        
        
        
        System.out.println(" We will Calculate the Compund Interest using the formula A = P (1 + n)*i ");
        System.out.println(" 1 is a contant so you will need to enter the other values to complete the formula and get your answer");
        
        for(int i = 0 ; i <count;   i++){
            System.out.println("(P) Enter the Principal Amount :  ");
            PrincAmount[i] = MM.nextDouble();
        }
        
         for(int i = 0 ; i <count;   i++){
            System.out.println("(i) Enter the Interest Amount  :  ");
            IntAmount[i] = MM.nextDouble();
        }
         
          for(int i = 0 ; i <count;   i++){
            System.out.println("(n) Enter the Number Of Years  :  ");
            NumOfYears[i] = MM.nextDouble();
        }
          
          for(int i = 0 ; i <count;   i++){
            double sum =PrincAmount[i] * (1 +  IntAmount[i]/100) * NumOfYears[i];
              System.out.println("The complete formula is ");
              System.out.println("A = " + PrincAmount[i] + " (1 +" +IntAmount[i] +" * " +")" + NumOfYears[i]);
              System.out.println("");
              System.out.println("The Compund Interest  is : " + sum);
        }

  
  
  System.out.println("");
    }
    
    public void DepStrLn(){
        // Deppreciation on straight line A=P(1-in)
        
        
        double[ ] PrincAmount = new double[ 1]; 
        double[ ] IntAmount = new double[ 1]; 
        double[ ] NumOfYears = new double[ 1]; 
        int count =1;
        
        
        
        System.out.println(" We will  calculate the Deppreciation amount using the straight Line Method using the formula  A=P(1-in)");
        System.out.println(" 1 is a contant so you will need to enter the other values to complete the formula and get your answer");
        
        for(int i = 0 ; i <count;   i++){
            System.out.println("(P) Enter the Principal Amount :  ");
            PrincAmount[i] = MM.nextDouble();
        }
        
         for(int i = 0 ; i <count;   i++){
            System.out.println("(i) Enter the Interest Amount  :  ");
            IntAmount[i] = MM.nextDouble();
        }
         
          for(int i = 0 ; i <count;   i++){
            System.out.println("(n) Enter the Number Of Years  :  ");
            NumOfYears[i] = MM.nextDouble();
        }
          
         for(int i = 0 ; i <count;   i++){
            double sum =PrincAmount[i] * (1 +  IntAmount[i]/100 - NumOfYears[i]);
              System.out.println("The complete formula is ");
              System.out.println("A = " + PrincAmount[i] + " (1 -" +IntAmount[i] +" * " +  NumOfYears[i]+")");
              System.out.println("");
              System.out.println("The Deppreciation amount using the straight Line Method is : " + sum);
        }
        
        System.out.println("");
    }
    
    public void RedBal(){
        // A=P(1 - i)*n Depreciation on a reducing balance method
         double[ ] PrincAmount = new double[ 1]; 
        double[ ] IntAmount = new double[ 1]; 
        double[ ] NumOfYears = new double[ 1]; 
        int count =1;
        
        
        
        System.out.println(" We will  calculate the Calculate Deppreciation amount using the Reducing Balance Method using the formula  A=P(1 - i)*n");
        System.out.println(" 1 is a contant so you will need to enter the other values to complete the formula and get your answer");
        
        for(int i = 0 ; i <count;   i++){
            System.out.println("(P) Enter the Principal Amount :  ");
            PrincAmount[i] = MM.nextDouble();
        }
        
         for(int i = 0 ; i <count;   i++){
            System.out.println("(i) Enter the Interest Amount  :  ");
            IntAmount[i] = MM.nextDouble();
        }
         
          for(int i = 0 ; i <count;   i++){
            System.out.println("(n) Enter the Number Of Years  :  ");
            NumOfYears[i] = MM.nextDouble();
        }
          
         for(int i = 0 ; i <count;   i++){
            double sum =PrincAmount[i] * (1 +  IntAmount[i]/100 - NumOfYears[i]);
              System.out.println("The complete formula is ");
              System.out.println("A = " + PrincAmount[i] + " (1 -" +IntAmount[i] +" * " + ")" + NumOfYears[i]);
              System.out.println("");
              System.out.println("The Deppreciation amount using the Reducing Balance Method : " + sum);
        }
        
        
        
        
        
        
        System.out.println("");
    }
    
    public void Exit(){
        System.out.println("Exiting the application!!");
        System.exit(0);
        
       
    }
    
    
    
    
}
