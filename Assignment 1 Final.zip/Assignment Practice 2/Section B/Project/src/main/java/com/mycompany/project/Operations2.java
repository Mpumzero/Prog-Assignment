/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author JABULANI
 */
public class Operations2 extends Operations {
     
    @Override
    public void SimpleInterest(){
        System.out.println("Simple interest is calculated by multiplying the principal, the amount of money that is initially invested or borrowed, by the rate, the speed at which the interest grows, and the time, how long money is being invested or borrowed.");
    }
    
    @Override
    public void CompundInterest(){
        System.out.println("Compound interest is calculated by multiplying the initial principal amount by one plus the annual interest rate raised to the number of compound periods minus one. The total initial principal or amount of the loan is then subtracted from the resulting value.");
    }
 
    public void DepStrLn(){
        System.out.println("Straight-line depreciation is calculated by dividing a fixed asset's depreciable base by its useful life. The depreciable base is the difference between an asset's all-in costs and the estimated salvage value at the end of its useful life.");
    }
     public void RedBal(){
         System.out.println("The calculation is simple: multiplying the carrying value of an asset (Net book value) by a consistent annual percentage (depreciation rate) to determine periodic depreciation charges.");
     }
    
    
}
