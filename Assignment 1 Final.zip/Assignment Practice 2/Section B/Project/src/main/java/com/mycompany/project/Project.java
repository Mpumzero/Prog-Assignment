/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project;

import java.util.Scanner;

/**
 *
 * @author JABULANI
 */
public class Project {

    public static void main(String[] args) {
        Scanner MM = new Scanner(System.in);
        Operations obj = new Operations();
        
        
        System.out.println("Welcome to the Finencial Maths Application");
        System.out.println("");
        System.out.println("This is a business Application which solves finencial issues");
        
        System.out.println("Enter (1) to see the menu or any other key to exit : ");
        String UserChoice = MM.nextLine();
        
        if(UserChoice.equals("1")){
            
            while (true){
              
             System.out.println("Choose whether you want to ");
        System.out.println("(1) Calculate Simple Interest");
        System.out.println("(2) Calculate Compound Interest");
         System.out.println("(3) Calculate Deppreciation of something using the straight Line Method");
         System.out.println("(4) Calculate Deppreciation of something using the Reducing Balance method Method");
         System.out.println("(5) Exit the Application");
         System.out.println("Enter your choice here : ");
         String Choice = MM.nextLine();
        
             
             
             if(Choice.equals("1")){
                 obj.SimpleInterest();
             }
             
             if( Choice.equals("2")){
                 obj.CompundInterest();
             }
             
             if( Choice.equals("3")){
                 obj.DepStrLn();
             }
             
             if( Choice.equals("4")){
                 obj.RedBal();
             }
             
             if( Choice.equals("5")){
                 obj.Exit();
                 System.exit(0);
                 break;
             }
             
             System.out.println("Enter (1) to see the menu or any other key to exit : ");
        UserChoice = MM.nextLine();
             System.out.println("Choose whether you want to ");
        System.out.println("(1) Calculate Simple Interest");
        System.out.println("(2) Calculate Compound Interest");
         System.out.println("(3) Calculate Deppreciation amount using the straight Line Method");
         System.out.println("(4) Calculate Deppreciation amount using the Reducing Balance method Method");
         System.out.println("(5) Exit the Application");
         System.out.println("Enter your choice here : ");
          Choice = MM.nextLine();
   
             
         }
            
        }
        
   
    }
}
