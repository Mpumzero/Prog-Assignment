/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.project;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 *
 * @author JABULANI
 */

public class ProjecTest {
    Calculations calc;
    @BeforeEach
    public void setup() {
        calc = new Calculations();
    }
    @Test
    public void testSimpleInterest() {
        double si = calc.calculateSimpleInterest(1000, 5, 2);
        assertEquals(100, si, 0.01);
    }
    @Test
    public void testCompoundInterest() {
        double ci = calc.calculateCompoundInterest(1000, 5, 2);
        assertEquals(102.5, ci, 0.01);
    }
    @Test
    public void testDepreciationStraightLine() {
        double depSL = calc.calculateDepreciationStraightLine(1000, 10, 3);

    }

    /**
     * Test of main method, of class Project.
     */
    @org.junit.jupiter.api.Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Project.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
